import $ from 'jquery';
window.jQuery = $;

export default $;